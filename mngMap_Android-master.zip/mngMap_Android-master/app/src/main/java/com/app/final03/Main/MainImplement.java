package com.app.final03.Main;

import android.content.Intent;

import com.app.final03.Model.Place;

public interface MainImplement {
    public  void onNavigationWithGGMap(Place place);
}
