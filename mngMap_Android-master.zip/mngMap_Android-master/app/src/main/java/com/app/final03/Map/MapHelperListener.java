package com.app.final03.Map;

import android.location.Location;

public interface MapHelperListener {
    void  onGetLocationSuccess(Location location);
}
