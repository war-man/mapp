package com.app.final03.Model;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.location.LocationManager.GPS_PROVIDER;

public class myModel {
    private myModelListener listener;
    private  Context context;
    private myConnectSqlite sqlite;
    //data
    private static ArrayList<Place> listAllPlace =new ArrayList<>();
    private static ArrayList<String> listHistory=new ArrayList<>();
    private  static  ArrayList<Integer> listIDPlaceSave=new ArrayList<>();

    public myModel(Context context) {
        this.context = context;
    }

    public  myModel(Context context, myModelListener listener){
        this.context=context;
        this.listener=listener;
    }

    //region Method
    public  void  readData() {
        sqlite = new myConnectSqlite(context);
        listAllPlace = sqlite.getAllPlace();
        if (listAllPlace == null) {
            if (readFromJson())
                sqlite.insertOfPlace(listAllPlace);
             else {
                Log.e("Tag", "Data Fail");
                listener.onFail();
            }
        } else {
        listHistory = sqlite.getListHistory();
        listIDPlaceSave = sqlite.getIDsSaved();
        listener.onSuccess(listAllPlace,listIDPlaceSave,listHistory);
        }
    }

    public  void  saveData(){
        Log.e("Tag","Save Data");
        sqlite.saveToSQLite(listIDPlaceSave,listHistory);
    }


    public  ArrayList<Place> getListWithDistance(int distance, Location location){
        ArrayList<Place> places = new ArrayList<>();
        for (Place p: listAllPlace) {
            if (p.distanceTo(location)<=distance)
                places.add(p);
        }
        return  places;
    }

    public  void  Sort(ArrayList<Place> list, Location location){
//        int min=9999;
//        for (int i =0;i<list.size();i++){
//            for (int j=0;j<list.size();j++){
//                if (list.get(i).distanceTo(location)>)
//            }
//        }
    }

    public Location getLocationFromAddress(String address) {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        Location location = new Location(GPS_PROVIDER);
        try {
            List<Address> addressList = geocoder.getFromLocationName(address, 1);
            if (addressList.size() > 0) {
                double lat = addressList.get(0).getLatitude();
                double lon = addressList.get(0).getLongitude();
                location.setLatitude(lat);
                location.setLongitude(lon);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return location;
    }


        //List save
    public ArrayList<Place> getListPlaceSave(){
        if (listIDPlaceSave.size()>0){
            ArrayList<Place> placeSave= new ArrayList<>();
            for (int i=0;i<listIDPlaceSave.size();i++){
                placeSave.add(listAllPlace.get(listIDPlaceSave.get(i)));
            }
            return placeSave;
        }
        else
            return  null;
    }

    //endregion

    private boolean readFromJson(){
        myJson json= new myJson();
        try {
            listAllPlace=  json.ReadFile(context);
            return  true;
        } catch (JSONException e) {
            return  false;
        }
    }



    public  interface  myModelListener{
        void onSuccess( ArrayList<Place> allPlace, ArrayList<Integer> lisIDSave, ArrayList<String> lisHistory );
        void  onFail();
    }
}
